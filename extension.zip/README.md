# HF Size
> Chrome extension to calculate the aggregate size of a Hugging Face directory

After installing the extension, navigate to a Hugging Face directory and the size will be displayed above the file list.

> ![](screenshot.png)
